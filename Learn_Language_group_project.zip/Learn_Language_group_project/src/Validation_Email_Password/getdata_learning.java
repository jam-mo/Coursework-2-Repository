/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Validation_Email_Password;

/**
 *
 *@author kokmeng / christopher / Jamie
 */

public abstract class getdata_learning {
    
    
    abstract protected boolean context( String level);
    
    abstract protected boolean subcontext(String context, String level);
    
    abstract protected boolean ReadtextA(String subContext, String level);
    
    abstract protected boolean ReadContext(String subContext,String level);
    
}
